# coding: utf-8

from setuptools import setup, find_packages

setup(name = "djangotasks",
    author="Francois Granade",
    author_email="farialima@gmail.com",
    version="0.51",
    packages=find_packages(),
    include_package_data=True,
    zip_safe=True,
)